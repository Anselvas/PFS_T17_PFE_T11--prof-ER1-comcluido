var num1;
let num2;

function somarDoisNumeros(numeroA, numeroB){
    return numeroA + numeroB
}

let resultado = somarDoisNumeros(10, 15)

console.log(resultado)

