//variaveis
let num1;
let num2;
let resultado;

//entrada
num1 = 1;
num2 = 5;

//processamento
resultado = num1 + num2;

//saída
console.log(resultado);



