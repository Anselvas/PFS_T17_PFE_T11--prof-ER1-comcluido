let numero;

numero = 8;

switch (numero) {
    case 1:
        console.log("O numero selecionado foi 1")
        break;
    case 2:
        console.log("O numero selecionado foi 2")
        break;
    case 3:
        console.log("O numero selecionado foi 3")
        break;
    case 4:
        console.log("O numero selecionado foi 4")
        break;
    default:
        console.log("Nao foi selecionado nenhum dos valores")
        break;
}