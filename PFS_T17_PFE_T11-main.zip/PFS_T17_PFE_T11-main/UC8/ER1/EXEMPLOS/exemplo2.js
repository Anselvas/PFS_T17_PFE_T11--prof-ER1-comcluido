//sistema para um radar de velocidade

//variaveis
let velocidade;

//entrada
velocidade = 110;

//processamento / saida
if (velocidade > 100){
    console.log("Voce foi multado!!!")
}
else{
    console.log("Voce esta dentro do limite de velocidade")
}


