//do while com contador - traduzindo é faça enquanto

let resposta; //variavel de controle

do {
    alert('Voce entrou no laço!!!')
    resposta = prompt('Para continuar digite s, para sair qualquer outra tecla')
} while (resposta == 's') //precisa de uma condição

//do while executa o laço pelo menos uma vez, mesmo que a condição
//seja falsa.




