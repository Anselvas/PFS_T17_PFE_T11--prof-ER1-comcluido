//do while com contador - traduzindo é faça enquanto

let contador = 100; //contador iniciando em 0

do {
    console.log(contador)
    //contador = contador + 1; //incremento
    contador ++
} while (contador < 100);//precisa de uma condição

//do while executa o laço pelo menos uma vez, mesmo que a condição
//seja falsa.

