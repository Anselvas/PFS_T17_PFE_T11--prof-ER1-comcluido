//for (laço mais utilizado, por ser simples), porém apenas permite
//laços contados, ou seja, com contador

for(contador = 0; contador < 100; contador ++)
{
    console.log(contador)
}

/*
incremento 
    contador (Exemplo: contador++) é a mesma coisa que contador = contador + 1

decremento
            (Exemplo: contador--) é a mesma coisa que contador = contador - 1
*/



