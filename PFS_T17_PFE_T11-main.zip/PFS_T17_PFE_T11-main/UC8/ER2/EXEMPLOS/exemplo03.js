//while com variável de controle

let resposta = 's'; //variavel de controle

while (resposta == 's') //precisa de uma condição
{
    alert('Voce entrou no laço!!!')
    resposta = prompt('Para continuar digite s, para sair qualquer outra tecla')
}