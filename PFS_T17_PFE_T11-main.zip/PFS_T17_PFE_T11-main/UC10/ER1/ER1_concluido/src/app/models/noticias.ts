export interface Noticias {
    id?: number;
    titulo: string;
    descricao: string;
    imagem: string;
}
