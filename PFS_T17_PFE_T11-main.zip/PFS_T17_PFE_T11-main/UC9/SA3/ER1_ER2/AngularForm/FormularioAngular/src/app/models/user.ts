export class User {
    constructor(
        public email?: string,
        public senha?: string
    ){}
}
